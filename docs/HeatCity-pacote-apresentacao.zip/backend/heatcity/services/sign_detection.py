"""Localização clássica de placas por correlação multiescala, sem treinamento."""

import io
import math
from time import perf_counter
from xml.sax.saxutils import escape

import cv2
import numpy as np
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from .vision import aoi_crop

SCALES = (0.5, 0.6, 2 / 3, 0.8, 1.0, 1.2, 1.5)
SCORE_MIN = 0.72
GAP_MIN = 0.06


def iou(a, b):
    left, top = max(a[0], b[0]), max(a[1], b[1])
    right, bottom = min(a[0] + a[2], b[0] + b[2]), min(a[1] + a[3], b[1] + b[3])
    intersection = max(0, right - left) * max(0, bottom - top)
    return intersection / max(1e-12, a[2] * a[3] + b[2] * b[3] - intersection)


def _quality(gray):
    low, high = np.percentile(gray, [1, 99])
    return dict(
        mean=float(gray.mean()),
        contrast=float((high - low) / (high + low + 1e-6)),
        sharpness=float(cv2.Laplacian(gray, cv2.CV_64F).var()),
    )


def detect(frame, reference, plates, annotations=None):
    start = perf_counter()
    h, w = frame.shape[:2]
    factor = min(1, 800 / w)
    work = cv2.resize(frame, (max(1, int(w * factor)), max(1, int(h * factor))))
    gray = cv2.cvtColor(work, cv2.COLOR_BGR2GRAY)
    rh, rw = reference.shape[:2]
    ref = cv2.resize(reference, (gray.shape[1], max(1, round(rh * gray.shape[1] / rw))))
    refgray = cv2.cvtColor(ref, cv2.COLOR_BGR2GRAY)
    results = []
    for plate in plates:
        patch = aoi_crop(refgray, plate)
        candidates = []
        if min(patch.shape) >= 8 and float(patch.std()) >= 3:
            for scale in SCALES:
                tw, th = round(patch.shape[1] * scale), round(patch.shape[0] * scale)
                if tw < 20 or th < 12 or tw > gray.shape[1] or th > gray.shape[0]:
                    continue
                template = cv2.resize(patch, (tw, th))
                response = cv2.matchTemplate(gray, template, cv2.TM_CCOEFF_NORMED)
                for _ in range(2):
                    _, score, _, loc = cv2.minMaxLoc(response)
                    if not math.isfinite(score):
                        break
                    x, y = loc
                    candidates.append(
                        dict(
                            score=float(score),
                            box=[
                                x / gray.shape[1],
                                y / gray.shape[0],
                                tw / gray.shape[1],
                                th / gray.shape[0],
                            ],
                            scale=scale,
                        )
                    )
                    response[
                        max(0, y - th // 2) : min(response.shape[0], y + th // 2 + 1),
                        max(0, x - tw // 2) : min(response.shape[1], x + tw // 2 + 1),
                    ] = -2
        candidates.sort(key=lambda x: x["score"], reverse=True)
        best = candidates[0] if candidates else None
        second = (
            next((c for c in candidates[1:] if iou(c["box"], best["box"]) < 0.3), None)
            if best
            else None
        )
        score = best["score"] if best else 0
        gap = score - second["score"] if second else None
        status = (
            "detected"
            if score >= SCORE_MIN and (gap is None or gap >= GAP_MIN)
            else "ambiguous"
            if score >= 0.55
            else "not_found"
        )
        reasons = []
        suggestions = []
        quality = None
        if not best:
            reasons.append("Recorte com pouca variação ou escala não pesquisável neste quadro.")
            suggestions.append(
                "Revisar o recorte de referência e aumentar o tamanho aparente da placa."
            )
        elif status == "not_found":
            reasons.append("Similaridade abaixo do limite; não identifica a causa isoladamente.")
            suggestions.append(
                "Testar câmera mais frontal, referência compatível e placa maior no enquadramento."
            )
        if best and 0.55 <= score < SCORE_MIN:
            reasons.append(
                "Similaridade intermediária: evidência insuficiente para confirmar a placa."
            )
            suggestions.append("Conferir nitidez, perspectiva e compatibilidade da referência.")
        if best and score >= 0.55 and gap is not None and gap < GAP_MIN:
            reasons.append("Mais de uma posição tem correlação semelhante.")
            suggestions.append(
                "Verificar placas visualmente parecidas e usar títulos/pictogramas mais distinguíveis."
            )
        quality_reasons, quality_suggestions = [], []
        if best and status == "detected":
            x, y, bw, bh = best["box"]
            roi = aoi_crop(gray, dict(x=x, y=y, width=bw, height=bh))
            q = _quality(roi)
            base = _quality(cv2.resize(patch, (roi.shape[1], roi.shape[0])))
            quality = {
                **q,
                "reference_sharpness": base["sharpness"],
                "reference_contrast": base["contrast"],
                "height_pixels": bh * h,
            }
            if base["sharpness"] > 10 and q["sharpness"] < base["sharpness"] * 0.5:
                quality_reasons.append(
                    "Menor variação pelo Laplaciano que a referência redimensionada; compatível com desfoque ou perda de detalhes."
                )
                quality_suggestions.append(
                    "Melhorar foco, reduzir movimento e posicionar a placa onde tenha maior tamanho aparente."
                )
            if base["contrast"] > 0.05 and q["contrast"] < base["contrast"] * 0.65:
                quality_reasons.append("Menor contraste local que a referência.")
                quality_suggestions.append(
                    "Evitar sombras/reflexos e aumentar a separação visual entre texto e fundo."
                )
            if bh * h < 28:
                quality_reasons.append("Altura aparente menor que 28 pixels nesta captura.")
                quality_suggestions.append(
                    "Aumentar a placa ou aproximá-la do percurso observado pela câmera."
                )
            if min(x, y, 1 - x - bw, 1 - y - bh) < 0.01:
                quality_reasons.append("Candidato próximo da borda do quadro; pode ser recortado.")
                quality_suggestions.append(
                    "Testar posição mais central no campo de visão e sem obstruções."
                )
        results.append(
            dict(
                name=plate["name"],
                status=status,
                score=score,
                second_score=second["score"] if second else None,
                gap=gap,
                box=best["box"] if best else None,
                scale=best["scale"] if best else None,
                reasons=reasons,
                suggestions=suggestions,
                quality=quality,
                quality_reasons=quality_reasons,
                quality_suggestions=quality_suggestions,
            )
        )
    # Different identities cannot be confidently assigned to the same rectangle.
    for i, a in enumerate(results):
        for b in results[i + 1 :]:
            if (
                a["box"]
                and b["box"]
                and min(a["score"], b["score"]) >= 0.55
                and iou(a["box"], b["box"]) > 0.35
            ):
                if abs(a["score"] - b["score"]) < 0.08:
                    a["status"] = b["status"] = "ambiguous"
                    for item, other in [(a, b), (b, a)]:
                        item["reasons"].append(
                            f"A mesma região também se parece com {other['name']}."
                        )
                        item["suggestions"].append(
                            "Diferenciar títulos/pictogramas e ampliar o espaçamento entre placas; testar antes de reposicionar."
                        )
                else:
                    weaker = min((a, b), key=lambda r: r["score"])
                    weaker["status"] = "conflict"
                    weaker["reasons"].append(
                        "Outro template tem correspondência mais forte na mesma região."
                    )
    for result in results:
        quality_reasons = result.pop("quality_reasons")
        quality_suggestions = result.pop("quality_suggestions")
        if result["status"] == "detected":
            result["reasons"].extend(quality_reasons)
            result["suggestions"].extend(quality_suggestions)
        else:
            result["quality"] = None
    metrics = dict(tp=0, fp=0, fn=0, tn=0, abstentions=0, annotations=0, ious=[])
    for annotation in annotations or []:
        before = metrics.copy()
        result = next(r for r in results if r["name"] == annotation["name"])
        metrics["annotations"] += 1
        positive = result["status"] == "detected"
        if annotation["present"]:
            overlap = iou(result["box"], annotation["box"]) if result["box"] else 0
            metrics["ious"].append(overlap)
            result["ground_truth_iou"] = overlap
            if positive and overlap >= 0.5:
                metrics["tp"] += 1
            else:
                metrics["fn"] += 1
                if positive:
                    metrics["fp"] += 1
        elif positive:
            metrics["fp"] += 1
        elif result["status"] == "not_found":
            metrics["tn"] += 1
        if result["status"] in ("ambiguous", "conflict"):
            metrics["abstentions"] += 1
        result["evaluation"] = {
            "present": annotation["present"],
            **{k: metrics[k] - before[k] for k in ("tp", "fp", "fn", "tn", "abstentions")},
        }
    elapsed = (perf_counter() - start) * 1000
    return dict(
        version="template_multiscale_v1",
        width=w,
        height=h,
        processing_ms=elapsed,
        signs=results,
        metrics=metrics if annotations else None,
        policy=dict(
            score_min=SCORE_MIN,
            spatial_gap_min=GAP_MIN,
            identity_gap_min=0.08,
            scales=list(SCALES),
            iou_min=0.5,
        ),
        note="Correlação não é probabilidade de acerto. Sugestões são hipóteses de captura/posicionamento, não avaliação de atenção humana.",
    )


def known_presence(result):
    """Read explicit reference presence, retaining compatibility with existing exports."""
    evaluation = result.get("evaluation")
    if evaluation is None:
        return None
    if "present" in evaluation:
        return evaluation["present"]
    if evaluation.get("tp", 0) + evaluation.get("fn", 0):
        return True
    if evaluation.get("tn", 0) + evaluation.get("fp", 0):
        return False
    return None


def summarize(frames):
    totals = {k: 0 for k in ("tp", "fp", "fn", "tn", "abstentions", "annotations")}
    times = []
    ious = []
    counts = {}
    conditions = {}
    details = {}
    previous = None
    for frame in frames:
        t = frame.get("processing_ms")
        if isinstance(t, (int, float)) and math.isfinite(t) and t >= 0:
            times.append(t)
        m = frame.get("metrics") or {}
        for k in totals:
            totals[k] += int(m.get(k, 0))
        if frame.get("condition"):
            condition = conditions.setdefault(
                frame["condition"],
                dict(condition=frame["condition"], frames=0, tp=0, fp=0, fn=0, tn=0),
            )
            condition["frames"] += 1
            for key in ("tp", "fp", "fn", "tn"):
                condition[key] += int(m.get(key, 0))
        ious.extend(
            float(v) for v in m.get("ious", []) if isinstance(v, (int, float)) and 0 <= v <= 1
        )
        for result in frame.get("signs", []):
            name = result["name"]
            c = counts.setdefault(name, dict(detected=0, ambiguous=0, not_found=0, conflict=0))
            if result["status"] in c:
                c[result["status"]] += 1
            d = details.setdefault(
                name,
                dict(
                    name=name,
                    frames=0,
                    detected_seconds=0,
                    events=0,
                    first_seen=None,
                    reasons={},
                    suggestions={},
                    scores=[],
                    gaps=[],
                    tp=0,
                    fp=0,
                    fn=0,
                    tn=0,
                    annotations=0,
                    known_present_frames=0,
                    known_absent_frames=0,
                ),
            )
            d["frames"] += 1
            d["scores"].append(float(result["score"]))
            if result.get("gap") is not None:
                d["gaps"].append(float(result["gap"]))
            presence = known_presence(result)
            d["known_present_frames"] += int(presence is True)
            d["known_absent_frames"] += int(presence is False)
            for key in ("reasons", "suggestions"):
                for value in set(result.get(key, [])) if presence is not False else []:
                    d[key][value] = d[key].get(value, 0) + 1
            if result.get("evaluation") is not None:
                d["annotations"] += 1
                for key in ("tp", "fp", "fn", "tn"):
                    d[key] += result["evaluation"][key]
            if result["status"] == "detected" and isinstance(frame.get("time"), (int, float)):
                d["first_seen"] = frame["time"] if d["first_seen"] is None else d["first_seen"]
                dt = frame["time"] - previous.get("time", frame["time"]) if previous else 0
                continuous = (
                    previous
                    and previous.get("source") == frame.get("source")
                    and 0 < dt <= 1.5
                    and any(
                        r["name"] == name and r["status"] == "detected"
                        for r in previous.get("signs", [])
                    )
                )
                if continuous:
                    d["detected_seconds"] += dt
                else:
                    d["events"] += 1
        previous = frame
    for name, d in details.items():
        d["mean_score"] = float(np.mean(d.pop("scores")))
        gaps = d.pop("gaps")
        d["mean_gap"] = float(np.mean(gaps)) if gaps else None
        d["detection_fraction"] = counts[name]["detected"] / d["frames"]
        d["uncertainty_fraction"] = (counts[name]["ambiguous"] + counts[name]["conflict"]) / d[
            "frames"
        ]
        d["precision"] = d["tp"] / (d["tp"] + d["fp"]) if d["tp"] + d["fp"] else None
        d["recall"] = d["tp"] / (d["tp"] + d["fn"]) if d["tp"] + d["fn"] else None
    return dict(
        frames=len(frames),
        **totals,
        precision=totals["tp"] / (totals["tp"] + totals["fp"])
        if totals["tp"] + totals["fp"]
        else None,
        recall=totals["tp"] / (totals["tp"] + totals["fn"])
        if totals["tp"] + totals["fn"]
        else None,
        mean_iou=float(np.mean(ious)) if ious else None,
        mean_processing_ms=float(np.mean(times)) if times else None,
        counts=counts,
        conditions=list(conditions.values()),
        details=list(details.values()),
    )


def report_pdf(frames, title="HeatCity — detecção de placas em vídeo"):
    output = io.BytesIO()
    styles = getSampleStyleSheet()
    story = []

    def text(value, style="BodyText"):
        story.extend([Paragraph(escape(str(value)), styles[style]), Spacer(1, 8)])

    text(title, "Title")
    text(
        "Problema: investigar a localização automática de placas cadastradas em imagens de ambientes coletivos. Detectar uma placa na câmera não comprova que uma pessoa a viu ou leu."
    )
    text("CitizenTech: necessidade, beneficiários e impacto", "Heading2")
    text(
        "Beneficiários propostos: pacientes, acompanhantes e visitantes que precisam se orientar até serviços como a Recepção. Responsáveis pelo espaço e pela sinalização operam o sistema para levantar hipóteses de visibilidade e testar alterações. A necessidade é ilustrativa neste ensaio: não foram apresentadas observações de território ou relatos de usuários."
    )
    text(
        "A câmera fornece dados e o processamento local automatiza indicadores para apoiar escolhas. ODS 3, meta 3.8: contribuição indireta pretendida ao acesso à orientação em serviços de saúde. ODS 11, meta 11.7: intenção de espaços coletivos acessíveis. O benchmark não demonstra cumprimento de metas nem ganho de acessibilidade. Fontes: https://sdgs.un.org/goals/goal3 e https://sdgs.un.org/goals/goal11 ."
    )
    text(
        "Impacto a verificar: tempo para localizar a placa, enganos e pedidos de ajuda antes/depois de uma alteração, com participação e consentimento dos usuários. O modelo de uso proposto é uma ferramenta local de apoio à manutenção; viabilidade de serviço, adoção e sustentabilidade financeira não foram medidas. O relatório diferencia resultado técnico de benefício cidadão."
    )
    text("Método", "Heading2")
    text(
        "OpenCV: conversão para cinza, template matching TM_CCOEFF_NORMED em sete escalas fixas, comparação com picos espaciais alternativos e conflitos entre identidades. Sem treino de modelos. Entrada de vídeo amostrada; não se afirma rastreamento contínuo ou identificação sem referência. Correlação mínima 0,72, margem espacial 0,06 e conflito de identidade 0,08 são heurísticos publicados, não probabilidades."
    )
    s = summarize(frames)
    text("Resultados e referência", "Heading2")
    text(
        f"Quadros analisados: {s['frames']}; anotações conhecidas: {s['annotations']}; TP={s['tp']}, FP={s['fp']}, FN={s['fn']}, TN={s['tn']}; abstenções={s['abstentions']}."
    )

    def fmt(value):
        return "indisponível" if value is None else f"{value:.3f}"

    text(
        f"Precisão: {fmt(s['precision'])}; recall: {fmt(s['recall'])}; IoU médio dos positivos anotados: {fmt(s['mean_iou'])}; processamento médio: {fmt(s['mean_processing_ms'])} ms."
    )
    text(
        "TP exige nome correspondente, decisão detectada e IoU >= 0,5. Placas não anotadas não são tratadas como ausentes. Erro de localização de uma detecção positiva gera FP e FN. Abstenções permanecem visíveis; se a placa estiver presente, contam como FN. Sem anotações não há precisão de acerto mensurada. Quadros correlacionados não são participantes independentes."
    )
    rows = [
        [
            Paragraph(label, styles["BodyText"])
            for label in ("Placa", "Detectada", "Ambígua", "Não localizada", "Conflito")
        ]
    ]
    for name, c in s["counts"].items():
        rows.append(
            [
                Paragraph(escape(name), styles["BodyText"]),
                *[str(c[k]) for k in ("detected", "ambiguous", "not_found", "conflict")],
            ]
        )
    table = Table(rows, colWidths=[170, 65, 65, 90, 65], repeatRows=1)
    table.setStyle(
        TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dfebe2")),
            ]
        )
    )
    story.append(table)
    if s["conditions"]:
        text("Resultados por trecho do arquivo", "Heading2")
        for condition in s["conditions"]:
            text(
                f"{condition['condition']}: {condition['frames']} quadros; TP={condition['tp']}, FP={condition['fp']}, FN={condition['fn']}, TN={condition['tn']}."
            )
        text(
            "O exemplo é decodificado em uma grade fixa de 24 quadros do MP4. Predições são recalculadas, não copiadas do benchmark. Os instantes são os do arquivo, independentemente do tempo de processamento. Vídeos próprios e webcam continuam amostrados ao vivo. O desfoque é uma transformação conhecida do experimento; falhar nesse trecho não comprova um problema de instalação da placa."
        )
    text("Análise final por placa: dificuldade, acerto e posicionamento", "Heading2")
    text(
        "Dificuldade operacional é descrita pela proporção de detecções, ambiguidades, falhas e margens de correlação; não é uma escala de dificuldade humana. Não localizada não significa comprovadamente ausente. Ausências conhecidas são separadas de falhas com placa presente. Nitidez, contraste e borda só geram alertas sobre candidatos aceitos; candidatos rejeitados não confirmam a região real da placa."
    )
    for d in s["details"]:
        text(d["name"], "Heading3")
        text(
            f"Detectada em {d['detection_fraction']:.1%} dos quadros; incerteza em {d['uncertainty_fraction']:.1%}. Similaridade média {fmt(d['mean_score'])}; margem espacial média {fmt(d['mean_gap'])}."
        )
        text(
            f"Tempo detectado estimado {d['detected_seconds']:.2f} s; {d['events']} trechos; primeira detecção em {fmt(d['first_seen'])} s da fonte. Intervalos entre quadros consecutivos detectados são somados somente na mesma fonte e até 1,5 s, sem preencher falhas. Quadro isolado soma zero. Não prova continuidade entre amostras."
        )
        text(
            f"Placa presente em {d['known_present_frames']} quadros anotados; ausente em {d['known_absent_frames']}. Ausências corretas (TN): {d['tn']}; falhas com placa presente (FN): {d['fn']}. Ausência confirmada não é usada como indício de dificuldade. Acerto por placa: {d['annotations']} anotações; precisão {fmt(d['precision'])}; recall {fmt(d['recall'])}; TP={d['tp']}, FP={d['fp']}, FN={d['fn']}, TN={d['tn']}."
        )
        if d["known_absent_frames"] == d["frames"]:
            text(
                "A placa estava ausente em todos os quadros anotados. Não é possível avaliar dificuldade ou sugerir outro local para ela a partir dessas ausências."
            )
            continue
        if not d["reasons"]:
            text(
                "Nenhum alerta heurístico de captura apareceu. Isso não comprova boa legibilidade ou ausência de erros."
            )
        for reason, count in sorted(d["reasons"].items(), key=lambda item: -item[1]):
            text(f"Indício em {count} quadros, excluindo ausências confirmadas: {reason}")
        for suggestion, count in sorted(d["suggestions"].items(), key=lambda item: -item[1]):
            text(f"Hipótese a testar ({count} quadros): {suggestion}")
        text(
            "Local da placa: testar instalação frontal ao percurso da câmera, antes do ponto de decisão, sem obstruções e com maior tamanho aparente. Comparar antes/depois com o mesmo trajeto, distância, câmera e iluminação, anotando a posição verdadeira. A análise não determina sozinha uma altura ou coordenada de instalação ideal."
        )
    text("Origem das referências", "Heading2")
    synthetic = sum(f.get("annotationSource") == "synthetic_geometry" for f in frames)
    manual = sum(f.get("annotationSource") == "manual_operator" for f in frames)
    text(
        f"Quadros com referência sintética: {synthetic}; com anotação manual do operador: {manual}. Os demais podem não ter anotação. Referência sintética não demonstra desempenho em vídeo real. A correlação não é probabilidade nem substitui a medição de acerto."
    )
    text("Limitações e conclusões", "Heading2")
    text(
        "Template matching é sensível a escala, inclinação, oclusão e mudanças de conteúdo. Baixo score não identifica sozinho qual fator causou a falha. Nitidez e contraste descrevem a região candidata e podem pertencer a uma correspondência incorreta. Sugestões de local significam hipóteses sobre visibilidade pela câmera; não demonstram melhor orientação ou acessibilidade humana. Precisam de nova captura/controlada para comparação."
    )
    text(
        "Referências: OpenCV Template Matching — https://docs.opencv.org/4.x/d4/dc6/tutorial_py_template_matching.html ; laboratório de aula — https://arnaldojr.github.io/cognitivecomputing/aulas/PDI/lab12/Template_matching.html ."
    )
    SimpleDocTemplate(output, leftMargin=42, rightMargin=42, topMargin=42, bottomMargin=42).build(
        story
    )
    return output.getvalue()
